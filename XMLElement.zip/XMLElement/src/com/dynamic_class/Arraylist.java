package com.dynamic_class;

//array of ArrayList 

import java.util.*; 
public class Arraylist { 
	public static void main(String[] args) {
		
		int n = 3;
		String root = "Root Node";
		String parent = "Parent Node";
		String firstName = "First Name";
		String lastName = "Last Name";
		String age = "Age";
		ListOfElements(n, root, parent, firstName, lastName, age);
		
	}

	private static void ListOfElements(int n, String root, String parent, String firstName, String lastName, String age) {
		ArrayList<ArrayList<String> > aList = new ArrayList<ArrayList<String> >(n); 
		ArrayList<String> a1 = new ArrayList<String>(); 
		a1.add("Root Node: "+root);  
		aList.add(a1); 

		ArrayList<String> a2 = new ArrayList<String>(); 
		a2.add("Parent Node: "+parent); 
		aList.add(a2); 

		ArrayList<String> a3 = new ArrayList<String>(); 
		a3.add("First Name: "+firstName); 
		a3.add("Last Name: "+lastName); 
		a3.add("Age: "+age); 
		aList.add(a3);
		
		for (int i = 0; i < aList.size(); i++) { 
			for (int j = 0; j < aList.get(i).size(); j++) { 
				System.out.println(aList.get(i).get(j) + " "); 
			} 
			System.out.println(); 
		}
		System.out.println("---------------------------------");
	}
}
 
