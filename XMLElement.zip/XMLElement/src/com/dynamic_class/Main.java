package com.dynamic_class;

import java.util.Scanner;

public class Main{
   public static void main (String args[]){
        int t;
        String input;
        int n;
        @SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
        t = sc.nextInt();
        while((t--)>0){
        	boolean alphabet = false;
        	int position = 0;
        	n = sc.nextInt();
        	input = "";
            for(int i=0;i<n;i++) {
            	String text = sc.next();
            	input = input + text + " ";
            }
            //System.out.println(input);
            for(int z=97;z<=122;z++) {
            	if(input.indexOf((char)z)!= -1) {
            	alphabet = true;
            	position = input.indexOf((char)z);
            	break;
            }
            }
            //System.out.println(alphabet);
            //System.out.println(position);
            //System.out.println(input.indexOf("#") != -1  &&  alphabet);
            if((input.indexOf("#") != -1)  &&  alphabet) {
            	String one = input.substring(0, position);
            	//System.out.println(one);
            	if(input.indexOf("#", position)>=0) {
            	String two = input.substring(position, input.indexOf("#", position));
            	//System.out.println(two);
            	String three = input.substring(input.indexOf("#", position));
            	//System.out.println(three);
            	System.out.println(three + two + one);
            	}else {
            		System.out.println(input.substring(position)+one);
            	}
            }else {
            System.out.println(input);
            }
       } 
   }
}
