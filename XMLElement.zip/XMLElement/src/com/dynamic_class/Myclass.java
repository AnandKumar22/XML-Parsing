package com.dynamic_class;

import com.xml.compressedXMLElement;

import org.w3c.dom.Element;

public class Myclass extends compressedXMLElement{
	String root, parent;
	public void sayHello() {
		System.out.println("Hello world from the loaded class!!");
	}
	
	public void rootclass(Element nodeelement){
		root = nodeelement.getNodeName();
		System.out.println("Root Element: "+root);
	}
	
	/*public String setroot(Element nodeelement) {
		return nodeelement.getNodeName();
	}*/
	
	public void parentnode(Element nodeelement){
		parent = nodeelement.getNodeName();
		System.out.println("Parent Node: "+parent);
	}
	
	public void attribute(Element documentElement){
		if(documentElement.getAttributes().getLength()>0) {
			System.out.println(documentElement.getNodeName()+"'s"+" Attribute :" + documentElement.getAttributes().item(0).getNodeName());
			System.out.println("Attribute Value :" + documentElement.getAttributes().item(0).getNodeValue());
		}
	}
	
	public void elementAttribute(Element element) {
		System.out.println("Element: "+element.getTagName());
  		 if(element.getAttributes().getLength()>0) {
			System.out.println(element.getNodeName()+"'s"+" Attribute :" + element.getAttributes().item(0).getNodeName());
			System.out.println("Attribute Value :" + element.getAttributes().item(0).getNodeValue());
		 }
  		 System.out.println(element.getTagName()+"'s"+" Value: "+element.getChildNodes().item(0).getNodeValue());
	}
}