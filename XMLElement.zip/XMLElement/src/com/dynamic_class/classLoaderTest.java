package com.dynamic_class;

public class classLoaderTest extends JavaClassLoader{
	public static void main(String[] args) {
		JavaClassLoader javaclassloader = new JavaClassLoader();
		javaclassloader.invokeClassMethod("com.dynamic_class.Myclass", "rootclass");
	}
}
