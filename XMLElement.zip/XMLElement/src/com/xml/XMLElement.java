package com.xml;

import java.io.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class XMLElement {
	public static void main(String argv[]) {
		try {
			File inputfile = new File("//Users//anandkumar//Documents//XML Parsing//XMLElement//src//com//xml//example.xml");
			DocumentBuilderFactory dbfactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dbuilder = dbfactory.newDocumentBuilder();
			Document doc = dbuilder.parse(inputfile);
			doc.getDocumentElement().normalize();
	         String root = doc.getDocumentElement().getNodeName();
	         System.out.println("Root element :" + root);
	         
	         System.out.println("---------Root Child----------");
	         NodeList children = doc.getDocumentElement().getChildNodes();
	         System.out.println(children.getLength());
	         for(int i=0;i<children.getLength();i++) {
	        	 System.out.println("i:"+i+" Type: "+ children.item(i).getNodeType());
		         Node current = children.item(i);
	         if(current.getNodeType() == Node.ELEMENT_NODE) {
	        	 Element element = (Element) current;
	        	 System.out.println("Element: "+element.getTagName());
	         } else {
	        	 System.out.println("Text: "+current.getTextContent());
	         }
	         System.out.println();
	         }
	         
	         System.out.println("---------Student Child----------");
	         //NodeList nList = doc.getElementsByTagName("student");
	         NodeList nList = doc.getElementsByTagName(doc.getDocumentElement().getChildNodes().item(1).getNodeName());
	         System.out.println(nList.getLength());
	         for(int i=0;i<nList.getLength();i++) {
	        	 System.out.println("i:"+i+" Type: "+ nList.item(i).getNodeType());
		         Node current = nList.item(i);
	         if(current.getNodeType() == Node.ELEMENT_NODE) {
	        	 Element element = (Element) current;
	        	 System.out.println("Element: "+element.getNodeName());
	        	 System.out.println("Child nodes of element:"+element.getChildNodes().getLength());
	        	 NodeList children2 = element.getChildNodes();
		         System.out.println(children2.getLength());
		         System.out.println();
		         for(int j=0;j<children2.getLength();j++) {
		        	 System.out.println("j:"+j+" Type: "+ children2.item(j).getNodeType());
			         Node current2 = children2.item(j);
		         if(current2.getNodeType() == Node.ELEMENT_NODE) {
		        	 Element element2 = (Element) current2;
		        	 System.out.println("Child nodes of "+element2.getTagName()+": "+element2.getChildNodes().getLength());
		        	 System.out.println("Element: "+element2.getTagName());
		        	 System.out.println("Value: "+ element2.getChildNodes().item(0).getTextContent());
		         } else {
		        	 System.out.println("Text: "+current2.getTextContent());
		         }
		         System.out.println();
		         }
	        	 
	         } else {
	        	 System.out.println("Text: "+current.getTextContent());
	         }
	         System.out.println();
	         }
	         System.out.println("----------------------------");
	         
	         for (int temp = 0; temp < nList.getLength(); temp++) {
	            Node nNode = nList.item(temp);
	            System.out.println("\nCurrent Element :" + nNode.getNodeName());
	            //System.out.println("\nAttributes :" + nNode.getAttributes().item(0).getNodeName());
	            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	               Element eElement = (Element) nNode;
	               System.out.println("\nAttributes :" + eElement.getAttributes().item(0).getNodeName());
	               System.out.println("Student roll no : " + eElement.getAttribute("rollno"));
	               System.out.println("First Name : " + eElement.getElementsByTagName("firstname").item(0).getTextContent());
	               System.out.println("Last Name : " + eElement.getElementsByTagName("lastname").item(0).getTextContent());
	               System.out.println("Nick Name : " + eElement.getElementsByTagName("nickname").item(0).getTextContent());
	               System.out.println("Marks : " + eElement.getElementsByTagName("marks").item(0).getTextContent());
	            }
	         }
		} catch(ParserConfigurationException pce) {
			pce.printStackTrace();
		} catch(IOException ioe) {
			ioe.printStackTrace();
		} catch (SAXException sae) {
			sae.printStackTrace();
		}
	}
}