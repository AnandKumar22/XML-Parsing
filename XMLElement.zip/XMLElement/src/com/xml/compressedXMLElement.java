package com.xml;

import java.io.*;

import com.dynamic_class.Myclass;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class compressedXMLElement{
	public static void main(String argv[]) {
		try {
			File inputfile = new File("//Users//anandkumar//Documents//XML Parsing//XMLElement//src//com//xml//example.xml");
			DocumentBuilderFactory dbfactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dbuilder = dbfactory.newDocumentBuilder();
			Document doc = dbuilder.parse(inputfile);
			doc.getDocumentElement().normalize();
			Myclass myclass = new Myclass();
			myclass.rootclass(doc.getDocumentElement());
	        System.out.println("------------------------------------");
	        System.out.println("------------------------------------");
	        Node_Tree_Creation(doc.getDocumentElement());
		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} catch (SAXException sae) {
			sae.printStackTrace();
		}
	}

	public static void Node_Tree_Creation(Element documentElement) {
  		 Myclass myclass = new Myclass();
  		 myclass.attribute(documentElement);
		NodeList children = documentElement.getChildNodes();
        for(int i=0;i<children.getLength();i++) {
	         Node current = children.item(i);
        if(current.getNodeType() == Node.ELEMENT_NODE) {
       	 Element element = (Element) current;
       	 if(element.getChildNodes().getLength()>1) {
       		 myclass.parentnode(element);
       		 System.out.println();
       		 Node_Tree_Creation(element);
       	 } else if(!(element.getChildNodes().item(0).getNodeValue().equals(null))) {
       		 myclass.elementAttribute(element);
       	 } else {
       		 System.out.println("The Element"+element.getTagName()+"is not a leaf node.");
       	 }
        }
        }
        System.out.println("------------------------------------");
	}
}